/*百度主动实时自动推送代码开始*/
(function(){

var bp = document.createElement('script');

var curProtocol = window.location.protocol.split(':')[0];

if (curProtocol === 'https') {

bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';

}

else {

bp.src = 'http://push.zhanzhang.baidu.com/push.js';

}

var s = document.getElementsByTagName("script")[0];

s.parentNode.insertBefore(bp, s);

})();
/*百度主动实时自动推送代码束*/

/*<!--360自动收录--> */
/*
(function(){
var src = "https://s.ssl.qhres2.com/ssl/ab77b6ea7f3fbf79.js";
document.write('<script src="' + src + '" id="sozz"><\/script>');
})();*/
/*<!--360自动收录--> */
/*<!--头条搜索收录--> */

(function(){
var el = document.createElement("script");
el.src = "https://sf1-scmcdn-tos.pstatp.com/goofy/ttzz/push.js?d645ee6d6c6c0d7aa10b4a79d1d401467b11aa53889a124e4fec0c9e3d05d02b00cd9968005346035157a70fcb3d7ccc5fdca5893d01c4297b1457b08ebf11fe";
el.id = "ttzz";
var s = document.getElementsByTagName("script")[0];
s.parentNode.insertBefore(el, s);
})(window)
/*<!--头条搜索收录--> */